package com.example.demo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface EmpolyeeRepo extends JpaRepository<Empolyee, Integer>{
	@Query("select empolyee from Empolyee empolyee where empolyee.empname=?1")
	public List<Empolyee> findByname(String name);


	
}
