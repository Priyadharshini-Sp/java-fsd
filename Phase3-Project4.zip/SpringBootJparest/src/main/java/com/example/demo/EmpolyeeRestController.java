package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController

public class EmpolyeeRestController {
	@Autowired
	EmpolyeeDAO dao;
	
@PostMapping("/insert")
	public Empolyee insert(@RequestBody Empolyee e) {
		return dao.insert(e);
	}


@PostMapping("/insertall")
public List<Empolyee> insertall(@RequestBody List<Empolyee> e){
	return dao.insertall(e);
}


@GetMapping("/getall")
public List<Empolyee> getall(){
	return dao.getall();
}

@PutMapping("/update")
public Empolyee updateByName(@RequestBody Empolyee e) {
	return dao.updateByName(e);
}


@DeleteMapping("/delete/{id}")
public String delete(@PathVariable  int id) {
	 return dao.delete(id);
	 
}
@GetMapping("/getbyname/{name}")
public List<Empolyee> findbyname(@PathVariable String name){
	return dao.findbyname(name);
}



}
