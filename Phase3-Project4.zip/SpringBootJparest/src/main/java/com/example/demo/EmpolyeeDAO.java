package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class EmpolyeeDAO {
	@Autowired
	EmpolyeeRepo repo;
	
	public Empolyee insert(Empolyee e) {
		return repo.save(e);
	}
	
	
	public List<Empolyee> insertall(List<Empolyee> e){
		return repo.saveAll(e);
	}
	
	public List<Empolyee> getall(){
		return repo.findAll();
	}
	
	
	public Empolyee getbyid(int id) {
		return repo.getById(id);
	}
	
	public String delete(int id) {
		 repo.deleteById(id);
		 return "deleted the id "+id;
	}
	public List<Empolyee> findbyname(String name){
		return repo.findByname(name);
	}

	
	/*in jpa we dont have a inbuilt update command 
	1.we fetch the record from the table  
	2.we set the value 
	3. we save the value(insert)*/
                            // 1 suresh s@c.c ->from controller   // 1 karthik s@c.c ->inserted into the table	
	public Empolyee updateByName(Empolyee e) {
		//1.we fetch the record from the table
		Empolyee ee=repo.findById(e.getEmpno()).orElse(null);// 1 karthik s@c.c
		ee.setEmpname(e.getEmpname());//karthik->suresh
		return repo.save(ee);
		
	}


}
