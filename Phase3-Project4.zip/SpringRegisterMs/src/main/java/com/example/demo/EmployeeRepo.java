package com.example.demo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface EmployeeRepo extends JpaRepository<Employee, String> {
	@Query("select employee from Employee employee where employee.user=?1")
	public Employee findByuser(String name);
	
	@Query("select employee from Employee employee where employee.password=?1")
	public Employee findBypassword(String name);


}
