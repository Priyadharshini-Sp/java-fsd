package Tickets;

import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		System.out.println("^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^");
		System.out.println("---------WELCOME TO ONLINE MOVIE TICKET BOOKING------");
		System.out.println("^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^");
		
		HomePage obj=new HomePage();
		obj.verify();
		
		
	}

}
